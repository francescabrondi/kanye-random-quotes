import React from "react";

const QuoteItem = ({ quote }) => {
  return <li>{quote}</li>;
};

export default QuoteItem;
