// import React, { useState, useEffect } from "react";
// import QuoteItem from "./components/QuoteItem";
// // import axios from "axios";

// const App = () => {
//   const [values, setValues] = useState([]);

//   const fetchQuotes = () => {
//     fetch("https://api.chucknorris.io/jokes/random")
//       .then(response => response.json)
//       .then(data => setValues([data.value, ...values]));
//   };

//   useEffect(() => fetchQuotes(), []);

//   return (
//     <div className="app">
//       <button onClick={fetchQuotes}>Aggiungi nuova citazione</button>
//       <ul>
//         {values.map((value, index) => (
//           <QuoteItem value={value} key={index} />
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default App;
