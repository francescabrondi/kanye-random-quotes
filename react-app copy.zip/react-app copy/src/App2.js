import React, { useState, useEffect } from "react";
import QuoteItem from "./components/QuoteItem";
// import axios from "axios";

const App = () => {
  const [hits, setHits] = useState([]);
  const [query, setQuery] = useState("");

  const fetchResults = query => {
    if (query !== "") {
      fetch(`https://hn.algolia.com/api/v1/search?query=${query}`)
        .then(response => response.json())
        .then(data => setHits(data.hits));
    }
  };

  useEffect(() => fetchResults(query), [query]);

  return (
    <div className="app">
      <input
        value={query}
        onChange={e => setQuery(e.target.value)}
        type="text"
        placeholder="Enter query..."
      />
      <ul>
        {hits.map((hit, index) => (
          <QuoteItem quote={hit.title} key={index} />
        ))}
      </ul>
    </div>
  );
};

export default App;
