import React from "react";
import ReactDOM from "react-dom";
import "./style.css";
import App2 from "./App2";

ReactDOM.render(<App2 />, document.getElementById("root"));
